# MC 原生通道

把 Minecraft 里的机器人接进 **AstrBot 原生消息链路**。

装上之后，服务器公屏上玩家说的话会像一条普通消息一样进 AstrBot：人设、长期记忆、各种插件钩子全部自动生效，不用再给游戏里单独维护一套 prompt。

## 链路

```
MC 服务器 ↔ play.js（只负责看和说）↔ 本地 unix socket ↔ 本插件（minecraft 平台）
                                                        ↓
                                            人设 / 记忆 / 插件钩子
```

`play.js` 从「大脑」退化成哑巴麦克风，思考全交给 AstrBot 这边。

两层上下文：

| 层 | 作用 | 谁维护 |
| --- | --- | --- |
| 会话层 | 记住「我和这个玩家刚聊了啥」，每个玩家一个独立会话 | AstrBot 自带 |
| 公屏层 | 知道「服里刚才大家在聊啥」，最近 N 条公屏滚动注入 | 本插件 |

## 安装

**方式：仓库 **

github仓库 → astrbot → 下载压缩包 → 安装。

然后在 AstrBot 管理面板 → 插件管理 → 重载插件。

> 本插件只负责管道，真正进服干活的 bot 在 [xiaoice-mcbot](https://github.com/kld157/xiaoice-mcbot)。

## 前置条件

1. 一个能正常聊天的 AstrBot（已配好 LLM 提供商）；
2. mcbot 仓库里的 `play.js` + `mc_ipc.js`，机器人能正常进服、能说话；
3. **两边在同一台机器上** —— unix socket 不支持跨机，要跨机得自己改成 TCP。

跑 Python 3.9+，除 AstrBot 本身外没有额外依赖。

## 配置

### 平台配置

管理面板 → 消息平台 → 新增 → 类型选「Minecraft 原生通道」→ 启用。

| 配置项 | 默认 | 说明 |
| --- | --- | --- |
| 连接路径 | `/AstrBot/data/plugin_data/mc_native/mc_ipc.sock` | socket 文件，**必须和 play.js 的 `MC_IPC_SOCK` 一致** |
| 机器人游戏名 | `xiaoice_bot` | 你在服务器里的 ID，用来排掉自己说的话 |
| 必答昵称 | `["小冰"]` | 公屏里出现这些词一定接话，写 `小冰,小冰冰` 也认 |
| 搭话概率 | `0.18` | 没人叫时的随机接话概率，嫌话少就调高 |
| 冷却秒数 | `60` | 两次回复至少隔多久，防刷屏 |
| 最多行数 | `4` | 一条回复最多拆成几条公屏 |
| 每段字数 | `22` | 每条公屏大概多长，超了会被拆开 |
| 公屏记忆条数 | `24` | 往上下文里塞多少条最近公屏 |
| 调试全部聊天 | `false` | 公屏每句都进 AstrBot，调试用，会烧 token |

改完平台配置需要重启 AstrBot。

### play.js 侧

在 mcbot 的 `mc.env` 里加一行，路径和上面「连接路径」保持一致：

```bash
MC_IPC_SOCK=/AstrBot/data/plugin_data/mc_native/mc_ipc.sock
```

然后正常启动（`./start.sh`）。进服后 AstrBot 日志应该出现：

```
[MC] play.js 已连上 ✓
[MC] 机器人已进服：xiaoice_bot (user=xxxx)
```

### 插件配置

管理面板 → 插件管理 → MC 原生通道。和平台配置是两套，别搞混。

| 配置项 | 默认 | 说明 |
| --- | --- | --- |
| `history_turns` | `8` | 每个玩家只保留最近 8 轮对话，聊久了自动收敛，防止上下文越来越肥 |
| `roll_enable` | `true` | 关掉后不再注入公屏滚动层，只看得见直接对她说的那句 |

## socket 路径必须对齐

这是最容易卡住的地方，两边默认值**不一样**：

- 本插件默认：`/AstrBot/data/plugin_data/mc_native/mc_ipc.sock`
- `mc_ipc.js` 默认：`<mcbot目录>/.mc_ipc.sock`

必须指向同一个文件。推荐统一到插件这边（就是上面「play.js 侧」那一步），`plugin_data/` 是 AstrBot 的数据目录，权限和清理都省心。改完两边都重启。

验证：

```bash
ls -l /AstrBot/data/plugin_data/mc_native/mc_ipc.sock
# 有 srw------- 就是建出来了
```

## 常见问题

**日志一直刷「还没连上（Connection refused）」**
路径没对上，或者 play.js 没启动。对照上面那节检查。

**她不说话，日志说「非纯文本消息（图片/表情等）在公屏发不出去，已跳过」**
MC 公屏只能发文字。LLM 返回图片、表情包组件时会被丢掉，把相关输出关掉即可。

**别人聊天她一直不接话**
查三处：必答昵称里有没有叫她、搭话概率是不是太低、冷却秒数是不是没过。调试期可以开「调试全部聊天」确认链路通不通。

**一次说好几行像刷屏**
调小「最多行数」，或调小「每段字数」。

**换成她主动说话没反应**
`play.js` 取消息后如果还没进服会被静默丢弃，等 `ready` 之后再试。

## 消息协议

一行一个 JSON，UTF-8 无 BOM。想做二次开发的话：

`play.js` → 本插件：

```jsonc
{"t":"ready","name":"xiaoice_bot","ver":"1.21.11"}   // 上线/重连同步状态
{"t":"chat","user":"Steve","msg":"小冰在吗"}          // 玩家公屏发言
{"t":"self","msg":"我在呀"}                          // 我自己说的话（用于排掉自己）
{"t":"hb","ts":1699999999}                           // 心跳，5s 一次
```

本插件 → `play.js`：

```jsonc
{"t":"say","text":"在的呀～"}   // 让我开口，切句在 Python 侧做完
```

## 版本

见 [CHANGELOG.md](./CHANGELOG.md)。

## License

MIT
