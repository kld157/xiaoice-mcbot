# -*- coding: utf-8 -*-
"""Minecraft 原生通道 —— AstrBot 平台适配器

链路：
    MC 服务器  <->  mcbot/play.js (mineflayer)  <->  本地 unix socket  <->  本适配器

为什么要有它：
  以前 play.js 自己拼 prompt 调 HTTP 接口，人设、记忆、插件钩子全是另开一套，
  越走越偏。现在 play.js 只当"眼睛和嘴"，看见的公屏、自己说的话走 socket 上来；
  AstrBot 当成一个正常平台来收发消息，所有已装的插件自动生效。

双层上下文：
  1. 会话层：每个玩家一个 session，天然有短记忆（由 AstrBot 自己维护）。
  2. 公屏层：全服最近 N 条公屏滚动注入 system prompt，让小冰知道"服里刚才在聊啥"。
"""

import asyncio
import json
import os
import random
import re
import time
from collections import deque
from typing import Any

from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.message_components import Plain
from astrbot.api.platform import (
    AstrBotMessage,
    MessageMember,
    MessageType,
    Platform,
    PlatformMetadata,
    register_platform_adapter,
)
from astrbot.api.provider import ProviderRequest
from astrbot.api.star import Context, Star, register

PLUGIN_NAME = "astrbot_plugin_mc_native"

DEFAULT_SOCK = "/AstrBot/data/plugin_data/mc_native/mc_ipc.sock"

# ---------------------------------------------------------------- 配置项键名
# 面板上直接显示键名，所以用中文。老版本存的是英文 key，读取时两个都认，
# 这样升级后已有的配置不会丢，面板刷新一下就是中文了。

K_SOCKET_PATH = "连接路径"
K_BOT_NAME = "机器人游戏名"
K_ALWAYS_NAMES = "必答昵称"
K_REPLY_PROB = "搭话概率"
K_COOLDOWN = "冷却秒数"
K_MAX_LINES = "最多行数"
K_SEG_LEN = "每段字数"
K_ROLL_SIZE = "公屏记忆条数"
K_DEBUG_ALL = "调试全部聊天"

_LEGACY_KEYS = {
    K_SOCKET_PATH: "socket_path",
    K_BOT_NAME: "bot_name",
    K_ALWAYS_NAMES: "always_names",
    K_REPLY_PROB: "reply_prob",
    K_COOLDOWN: "cooldown",
    K_MAX_LINES: "max_lines",
    K_SEG_LEN: "seg_len",
    K_ROLL_SIZE: "roll_size",
    K_DEBUG_ALL: "debug_all_chat",
}


def cfg_get(config: dict, key: str, default=None):
    """读配置：先认中文 key，没有就回落到老英文 key。"""
    if config.get(key) not in (None, "", []):
        return config[key]
    old = _LEGACY_KEYS.get(key)
    if old and config.get(old) is not None:
        return config[old]
    return default


def cfg_names(value) -> list[str]:
    """必答昵称容错：列表、'a,b' 字符串都认。"""
    if isinstance(value, str):
        raw = value.replace("，", ",").split(",")
    elif isinstance(value, (list, tuple)):
        raw = list(value)
    else:
        return []
    return [str(x).strip() for x in raw if str(x).strip()]


def migrate_legacy_keys(config: dict) -> None:
    """把老英文 key 就地搬到中文 key，搬完删掉英文的。

    不然面板会把中英两套都列出来，看着像配置项重复了。
    """
    for cn, en in _LEGACY_KEYS.items():
        if en not in config:
            continue
        val = config.pop(en)
        cur = config.get(cn)
        if cur in (None, "", []):
            config[cn] = val
        elif cn == K_ALWAYS_NAMES:
            # 中英都有昵称时合并去重，别把后加的名字弄丢
            config[cn] = list(dict.fromkeys(cfg_names(cur) + cfg_names(val)))

# ---------------------------------------------------------------- 公屏滚动池

class PublicRoll:
    """全服最近公屏。模块级单例，适配器写、Star 读。"""

    def __init__(self, size: int = 24):
        self.roll: deque = deque(maxlen=size)
        self.bot_name = "xiaoice_bot"

    def add(self, user: str, text: str) -> None:
        text = (text or "").strip()
        if not text:
            return
        self.roll.append((time.time(), user, text[:160]))

    def render(self) -> str:
        if not self.roll:
            return ""
        lines = []
        for _ts, user, text in list(self.roll):
            who = "我" if user == self.bot_name else user
            lines.append(f"{who}: {text}")
        return (
            "【服务器公屏 · 最近发言】\n"
            + "\n".join(lines)
            + "\n（这是 MC 服务器公屏的实时滚动记录，标「我」的是你自己说过的话。"
            "大家你一句我一句，不必回复其中每一条，只在合适的时候接话。）"
        )

    def set_bot_name(self, name: str) -> None:
        if name:
            self.bot_name = name


ROLL = PublicRoll()

# ---------------------------------------------------------------- 句子切分

_MD_LINK = re.compile(r"\[([^\]]*)\]\([^)]*\)")
_MD_NOISE = re.compile(r"[*_`#>]+")
_SENT = re.compile(r"[^。！？!?…~～\n]+[。！？!?…~～]*")
_BRACKET = re.compile(r"（[^）]*）|\([^)]*\)")


def split_for_mc(text: str, seg: int = 22, max_lines: int = 4) -> list[str]:
    """把一段回复切成若干条适合公屏的消息。

    MC 公屏一条太长会刷屏，也不好读。这里按句切、按字数合并，
    括号里的动作描写尽量整段保留，别把（歪头）切成（歪 头）。
    """
    if not text:
        return []
    t = _MD_LINK.sub(r"\1", str(text))
    t = _MD_NOISE.sub("", t)
    t = re.sub(r"\n{2,}", "\n", t).strip()
    if not t:
        return []

    # 先把括号动作整体提出来当不可分割单元
    pieces: list[str] = []
    for sent in _SENT.findall(t):
        s = sent.strip()
        if not s:
            continue
        for chunk in _split_keep_bracket(s):
            pieces.append(chunk)

    lines: list[str] = []
    buf = ""
    for p in pieces:
        if not buf:
            buf = p
        elif len(buf) + len(p) <= seg:
            buf += p
        else:
            lines.append(buf.strip())
            buf = p
    if buf.strip():
        lines.append(buf.strip())

    if len(lines) > max_lines:
        head = lines[: max_lines - 1]
        tail = "".join(lines[max_lines - 1 :])
        head.append(tail[: seg * 2])
        lines = head
    return [ln for ln in lines if ln][:max_lines]


def _split_keep_bracket(s: str) -> list[str]:
    """按括号边界切开，括号内的部分不拆。"""
    out, i, buf = [], 0, ""
    while i < len(s):
        m = _BRACKET.match(s, i)
        if m:
            if buf:
                out.append(buf)
                buf = ""
            out.append(m.group(0))
            i = m.end()
            continue
        buf += s[i]
        i += 1
    if buf:
        out.append(buf)
    return out


# ---------------------------------------------------------------- 平台适配器


@register_platform_adapter(
    "minecraft",
    "Minecraft 原生通道（mcbot/play.js 本地 socket）",
    default_config_tmpl={
        "type": "minecraft",
        "enable": False,
        "id": "minecraft",
        K_SOCKET_PATH: DEFAULT_SOCK,
        K_BOT_NAME: "xiaoice_bot",
        K_ALWAYS_NAMES: ["小冰"],
        K_REPLY_PROB: 0.18,
        K_COOLDOWN: 60,
        K_MAX_LINES: 4,
        K_SEG_LEN: 22,
        K_ROLL_SIZE: 24,
        K_DEBUG_ALL: False,
    },
    support_streaming_message=False,
)
class MCPlatformAdapter(Platform):
    def __init__(self, config: dict, settings=None, event_queue=None):
        # manager 调用是 (config, settings, event_queue)；兼容只有两个参数的老写法
        if event_queue is None and isinstance(settings, asyncio.Queue):
            settings, event_queue = None, settings
        super().__init__(config, event_queue)

        config = config or {}
        migrate_legacy_keys(config)
        self.sock_path = str(cfg_get(config, K_SOCKET_PATH, DEFAULT_SOCK) or DEFAULT_SOCK)
        self.bot_name = str(cfg_get(config, K_BOT_NAME, "xiaoice_bot") or "xiaoice_bot")
        self.always_names = cfg_names(cfg_get(config, K_ALWAYS_NAMES, ["小冰"])) or ["小冰"]
        self.reply_prob = float(cfg_get(config, K_REPLY_PROB, 0.35))
        self.cooldown = float(cfg_get(config, K_COOLDOWN, 60))
        self.max_lines = max(1, int(cfg_get(config, K_MAX_LINES, 4)))
        self.seg_len = max(4, int(cfg_get(config, K_SEG_LEN, 22)))
        self.debug_all_chat = bool(cfg_get(config, K_DEBUG_ALL, False))

        ROLL.set_bot_name(self.bot_name)
        ROLL.roll = deque(
            ROLL.roll, maxlen=max(1, int(cfg_get(config, K_ROLL_SIZE, 24)))
        )

        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        self._closing = False
        self._wlock = asyncio.Lock()
        self._last_reply = 0.0
        self._last_from: dict[str, float] = {}
        self._connected = False

    # ---- 生命周期

    def meta(self) -> PlatformMetadata:
        return PlatformMetadata(
            name="minecraft",
            description="Minecraft 原生通道",
            id=self.config.get("id", "minecraft"),
            support_streaming_message=False,
            support_proactive_message=True,
        )

    def run(self):
        return self._main()

    async def terminate(self):
        self._closing = True
        await self._close_transport()

    async def _close_transport(self):
        w, self._writer = self._writer, None
        self._reader = None
        self._connected = False
        if w:
            try:
                w.close()
                await w.wait_closed()
            except Exception:
                pass

    async def _main(self):
        delay = 2.0
        logger.info("[MC] 通道启动，等待 play.js 连接：%s", self.sock_path)
        while not self._closing:
            try:
                self._reader, self._writer = await asyncio.open_unix_connection(
                    self.sock_path
                )
            except (FileNotFoundError, ConnectionRefusedError) as e:
                logger.debug("[MC] 还没连上（%s），%.0fs 后重试", e, delay)
                await asyncio.sleep(delay)
                delay = min(delay * 1.5, 15.0)
                continue
            except Exception as e:
                logger.warning("[MC] 连接异常：%s，%.0fs 后重试", e, delay)
                await asyncio.sleep(delay)
                delay = min(delay * 1.5, 15.0)
                continue

            delay = 2.0
            self._connected = True
            logger.info("[MC] play.js 已连上 ✓")
            try:
                await self._read_loop()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.warning("[MC] 读循环中断：%s", e)
            finally:
                await self._close_transport()
                if not self._closing:
                    logger.info("[MC] 通道断开，等待重连…")
                    await asyncio.sleep(1.0)

    async def _read_loop(self):
        assert self._reader is not None
        while not self._closing:
            line = await self._reader.readline()
            if not line:
                return
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line.decode("utf-8", "replace"))
            except Exception:
                continue
            try:
                await self._handle(obj)
            except Exception:
                logger.exception("[MC] 处理消息失败")

    # ---- 收

    async def _handle(self, obj: dict):
        t = obj.get("t")
        # play.js 侧字段是 msg，python 侧习惯写 text，两边都认
        body = obj.get("text") or obj.get("msg") or ""
        if t == "ready":
            self.bot_name = obj.get("name") or self.bot_name
            ROLL.set_bot_name(self.bot_name)
            logger.info(
                "[MC] 机器人已进服：%s (user=%s)",
                obj.get("name"),
                obj.get("user"),
            )
        elif t == "chat":
            await self._on_chat(str(obj.get("user") or ""), str(body))
        elif t == "self":
            # 我自己说的话，记进公屏池就行，不用再走一遍 LLM
            ROLL.add(self.bot_name, str(body))
        elif t == "hb":
            return
        elif t == "bye":
            logger.info("[MC] play.js 主动下线")
        else:
            logger.debug("[MC] 未知消息：%s", obj)

    async def _on_chat(self, user: str, text: str):
        if not user or not text:
            return
        if user == self.bot_name:
            ROLL.add(user, text)
            return

        ROLL.add(user, text)
        self._last_from[user] = time.time()

        if not self._should_reply(user, text):
            return

        abm = AstrBotMessage()
        abm.type = MessageType.FRIEND_MESSAGE
        abm.self_id = self.bot_name
        abm.session_id = user                       # 一人一会话 -> 天然短记忆
        abm.message_id = f"mc_{int(time.time() * 1000)}_{random.randint(0, 999)}"
        abm.sender = MessageMember(user_id=user, nickname=user)
        abm.message = [Plain(text)]
        abm.message_str = text
        abm.raw_message = {"user": user, "text": text}
        abm.timestamp = int(time.time())
        self.commit_event(self.create_event(abm))
        self._last_reply = time.time()

    def _should_reply(self, user: str, text: str) -> bool:
        """该不该把这条公屏丢进 AstrBot。

        公屏人多的时候每句都触发的代价值得掂量，所以这里先过一遍筛子：
        被叫名字必回、问句大概率回、纯闲聊按概率接话，且整体有冷却。
        """
        low = text.lower()
        for n in self.always_names:
            if n and str(n).lower() in low:
                return True
        if self.debug_all_chat:
            return True

        now = time.time()
        # 刚跟这个人聊过，还在对话窗口内 -> 继续接
        if now - self._last_from.get(user, 0) < self.cooldown * 1.5 and (
            now - self._last_reply < self.cooldown
        ):
            return True
        if now - self._last_reply < self.cooldown:
            return False
        if "?" in text or "？" in text:
            return random.random() < 0.55
        if any(k in text for k in ("吗", "怎么", "为啥", "为什么", "谁", "哪")):
            return random.random() < 0.4
        return random.random() < self.reply_prob

    # ---- 发

    async def _write(self, obj: dict):
        if not self._writer:
            logger.debug("[MC] 没连上，丢弃：%s", obj)
            return False
        data = (json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8")
        async with self._wlock:
            try:
                self._writer.write(data)
                await self._writer.drain()
                return True
            except Exception as e:
                logger.warning("[MC] 写入失败：%s", e)
                await self._close_transport()
                return False

    async def send_by_session(self, session, message_chain) -> None:
        await super().send_by_session(session, message_chain)
        await self.send_chain(message_chain)

    async def send_chain(self, message_chain) -> None:
        text = "".join(
            c.text for c in message_chain.chain if isinstance(c, Plain) and c.text
        )
        if not text.strip():
            if any(not isinstance(c, Plain) for c in message_chain.chain):
                logger.info("[MC] 非纯文本消息（图片/表情等）在公屏发不出去，已跳过")
            return
        lines = split_for_mc(text, seg=self.seg_len, max_lines=self.max_lines)
        for i, ln in enumerate(lines):
            # 不在这里记公屏：play.js 播出去之后会用 {t:'self'} 回传，避免记两遍
            ok = await self._write({"t": "say", "text": ln})
            if not ok:
                return
            if i < len(lines) - 1:
                await asyncio.sleep(random.uniform(0.45, 1.1))


# ---------------------------------------------------------------- 插件入口


@register(
    PLUGIN_NAME,
    "小冰",
    "Minecraft 原生通道配套插件：公屏滚动层 + 上下文收敛",
    "v0.1.0",
)
class MCNativePlugin(Star):
    def __init__(self, context: Context, config: dict | None = None):
        super().__init__(context)
        self.context = context
        cfg = config or {}
        self.history_turns = int(cfg.get("history_turns", 8))
        self.roll_enable = bool(cfg.get("roll_enable", True))

    @filter.on_llm_request()
    async def inject_public_roll(self, event: AstrMessageEvent, req: ProviderRequest):
        """公屏层注入 + 会话历史收敛。

        会话层让模型记得「我和这个人刚说了啥」，公屏层让它知道「服里刚才在聊啥」。
        AstrBot 自己的会话历史会无限增长，这里顺手收到最近 N 轮，
        免得聊久了上下文越来越肥、越来越跑题。
        """
        if not self._is_mc(event):
            return

        # 1) 收敛会话历史
        keep = max(2, self.history_turns) * 2
        if len(req.contexts) > keep:
            req.contexts = req.contexts[-keep:]

        # 2) 注入公屏滚动
        if not self.roll_enable:
            return
        block = ROLL.render()
        if not block:
            return
        if block[:20] in (req.system_prompt or ""):
            return
        base = req.system_prompt or ""
        req.system_prompt = (base + "\n\n" + block).strip() if base else block

    @staticmethod
    def _is_mc(event: AstrMessageEvent) -> bool:
        try:
            if event.get_platform_name() == "minecraft":
                return True
        except Exception:
            pass
        try:
            return str(event.unified_msg_origin).startswith("minecraft:")
        except Exception:
            return False
