# Changelog

## v0.1.0

- 首个版本：`minecraft` 平台适配器，通过本地 unix socket 接 `mcbot/play.js` 的公屏聊天
- 每个玩家一个独立会话，复用 AstrBot 人设、记忆与插件钩子
- 公屏滚动层：最近 N 条公屏注入 system prompt；会话历史按 `history_turns` 收敛
- 接话策略：必答昵称必回、问句大概率回、闲聊按概率接，整体带冷却
- 输出侧按句切分、按字数合并，括号动作描写不被切断
- 兼容老版本英文配置键，启动时自动迁移为中文键
